import { Component, OnInit } from '@angular/core';
import { Book } from '../../book';
import { BOOKS } from '../../mock-books';
@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
  bookList: Book[] = BOOKS;
  constructor() { }

  ngOnInit() {
  }

}
